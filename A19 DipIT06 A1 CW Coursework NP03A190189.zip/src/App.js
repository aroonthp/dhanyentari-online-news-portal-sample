import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import International from './components/international';
import Business from './components/business';
import Sports from './components/sports';
import Footer from './components/footer';
import Nav from './components/nav';
import Home from './components/homepage';
import SkipAdd from './components/skipAdd';
import  About from './components/about';
import Entertainment from'./components/entertainment';

const App=()=>{
  return(
    <Router>
    <React.Fragment>
      <Nav/>
    <div >
      <Route  exact path ='/'  component={SkipAdd}></Route>
        <Route path="/homepage" component={Home} />
            <Route exact path="/international" component={International} />
            <Route exact path="/business" component={Business} />
            <Route exact path="/sports" component={Sports} />
            <Route exact path="/about" component={About}/>
            <Route exact path="/entertainment" component={Entertainment}/>

    </div>

     
      <Footer/>
      
    </React.Fragment>
    </Router>
  )

}
export default App;