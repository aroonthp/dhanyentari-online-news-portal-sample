import React from'react'

function Search(){
    return(
        <div className="searchbar">
			 <form >
		     <input type="text" placeholder="Search.." name="search" />
             <button type="click">search </button> 
             </form>
</div>  
  )
}
export default Search;
