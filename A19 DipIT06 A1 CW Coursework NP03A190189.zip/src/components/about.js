import React, { Component } from "react";

export default class About extends Component {
  submit = e => {
    let form = document.getElementById("subscribe");
    let email = document.getElementById("email");
    e.preventDefault();
    let subscribers = [];
    if (localStorage.getItem("subscribers")) {
      subscribers = JSON.parse(localStorage.getItem("subscribers"));
    }
    subscribers.push(email.value);
    localStorage.setItem("subscribers", JSON.stringify(subscribers));
    alert("thank you for subscribing");
  };

  render() {
    const rep = {
      marginLeft: "37%",
      marginTop: "3%"
    };
    const repp = {
      width: "300px",
      height: "300px"
    };
    return (
      <>
        <style>@import url('/css/about.css');</style>

        <div style={{ backgroundImage: "url(img/ab.jpg)" }}>
          <h1>About Us</h1>
          <div className="div1"> OUR MISSION</div>
          <p>
            Our mission is to bring latest news to the user with
            genuineess.digital data has been overchanged with the time .....etc
            etc.
          </p>
          <hr />
          <section id="newsletter" />
          <div className="container" />
          <h1>subscribe to our news letter</h1>
          <form id="subscribe" onSubmit={this.submit}>
            <input type="email" id="email" placeholder="enter email id" />
            <button type="submit" class="button_1">
              subscribe{" "}
            </button>
          </form>
          <br />

          <div className="middle" height="45%">
            <a className="btn" href="#">
              <i className="fab fa-facebook-f"></i>
            </a>
            <a className="btn" href="#">
              <i className="fab fa-twitter"></i>
            </a>
            <a className="btn" href="#">
              <i className="fab fa-google"></i>
            </a>
            <a className="btn" href="#">
              <i className="fab fa-instagram"></i>
            </a>
            <a className="btn" href="#">
              <i className="fab fa-youtube"></i>
            </a>
          </div>
          <hr />
           <div style={rep} className="flip-card">
            <div style={rep} className="flip-card">
              <div className="flip-card-inner">
                <div className="flip-card-front">
                 {/* // <img src="/img/logo.png" alt="Avatar" style={repp} /> */}
                </div>
                <div className="flip-card-back">
                  <h1>BibekJungThapa</h1>
                  <p>Marketing Mangaer</p>
                  <p> Contact:9849890000</p>
                  <hr />
                  <img src="/img/logo.png" height="100" width="100" />
                </div>
              </div>
            </div>
          </div> 
        </div>
        <hr />

        
      </>
    );
  }
}
