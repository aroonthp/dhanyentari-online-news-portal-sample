import React,{Component} from'react'

export default class Footer extends Component{
	constructor(props){
		super(props);
	}
	render(){
 return(
	 <React.Fragment>
		  <style>
			  @import url('/css/footer.css')
             </style>
        	
			<div className="clr"></div>
			<div className="footer">
				<img src="logo.png" alt="" height="10px" width="10px"/>
				<p>Copyright@All rights reserved @dhanyentarinews.com 2020</p>

			</div>
				
				
				</React.Fragment>
    );
	}
}