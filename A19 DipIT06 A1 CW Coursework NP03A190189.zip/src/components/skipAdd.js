import React from 'react';
import {Link} from 'react-router-dom';

export default function skipAdd() {

    return (
        <>
        <>
        <style>

            @import url('/css/international.css')
        </style>
        </>
        <div>
            <div className="preview-block">
		
                <a href="#" className="skip-ad"><h1></h1></a>
                <Link to ='/homepage' className="skip-ad"><h1>SKIP AD</h1></Link>
                <img src="https://media.edusanjal.com/gallery/Herald_College_4.jpg"  alt="centered image" />
            </div>
            
        </div>
        </>
    
    )
}
