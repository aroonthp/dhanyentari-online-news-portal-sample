import React, { Component } from "react";
import axios from "axios";

class Business extends Component {
  constructor(props) {
    super(props);
    this.submit = this.submit.bind(this) 
    this.state={
        data: [],
        popup: []
    };
  }

              componentDidMount(){
              fetch('http://localhost:5005/International')
			.then(response => response.json())
			.then(data => {
                    this.setState({data: data})
				})
		
            .catch(e => console.log(e))
        }
		
			popup = (e) => {
        document.querySelector("#popup").style.display = "block";
            	if(e.target.classList.contains('btn')){
				let id = e.target.dataset.id
				fetch('http://localhost:5005/International/'+id)
				.then(response=>response.json())
				.then(data => {
					this.setState({popup: data})			
				})
			}
            }
            submit(e) { //half
              e.preventDefault()
      
              axios.post('http://localhost:5005/Contact', {
                fname: document.querySelector("#fname").value,
                lname: document.querySelector("#lname").value
              })
              .then(() => {
                console.log("Success")
              }).catch(()=> {
                console.log("Error")
              })
      
              e.target.reset()
            }

  render() {
    const head = {
      display: "inline-block",
      width: "40%"
    };

    
    const { data } = this.state;
    const { popup } = this.state


    return (
      <React.Fragment>

{data.map(business=>(
		<div id="container">
		<img src={business.url} alt="" height="250" width="250"/> 
		<p style={head}>{business.title}</p>
		<button class="btn" data-id={business.id} onClick={this.popup}>Read More </button>
        </div>
        ))}
        <div id="popup">
           <h1> {popup.description} </h1>
        </div>
        <div className="seperate">

          <aside id="sidebar">
            <div className="dark">
              <h2>login Form </h2>

              <form action="/action_page.php">
                First name:
                <input type="text" name="firstname" value="Mickey" />
                Last name:
                <input type="text" name="lastname" value="Mouse" />
                <input type="submit" value="Submit" />
              </form>
            </div>
          </aside>
          

          <aside className="sidebar">
            <div className="dark">
              <h3>Add here</h3>
              <p> contact num</p>
            </div>
            <div className="dark">
              <h3>Add here</h3>
              <p> contact num</p>
            </div>
            <div className="dark">
              <h3>Add here</h3>
              <p> contact num</p>
            </div>
          </aside>
          {/* <hr /> */}
         </div>
      </React.Fragment>
    );
  }
}
export default Business;
