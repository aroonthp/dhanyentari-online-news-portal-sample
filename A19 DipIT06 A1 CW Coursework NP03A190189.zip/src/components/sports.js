import React, { Component } from "react";
import axios from 'axios';

class Sports extends Component {
  constructor(props) {
    super(props);
    this.state={
        data: [],
        popup: []
    };
  }

              componentDidMount(){
              fetch('http://localhost:5005/Sports')
			.then(response => response.json())
			.then(data => {
                    this.setState({data: data})
				})
		
            .catch(e => console.log(e))
        }

        submit(e) {
          e.preventDefault();

          axios.post('http://localhost:5005/contact')
          fname: document.querySelector("#fname")
          lname: document.querySelector("#lname")

        }
		
			popup = (e) => {
        document.querySelector("#popup").style.display = "block";
            	if(e.target.classList.contains('btn')){
				let id = e.target.dataset.id
				fetch('http://localhost:5005/sports/'+id)
				.then(response=>response.json())
				.then(data => {
					this.setState({popup: data})			
				})
			}
            }

  render() {
    const head = {
      display: "inline-block",
      width: "40%"
    };

    
    const { data } = this.state;
    const { popup } = this.state


    return (
      <React.Fragment>

{data.map(sports=>(
		<div id="container">
		<img src={sports.url} alt="" height="250" width="250"/> 
		<p style={head}>{sports.title}</p>
		<button class="btn" data-id={sports.id} onClick={this.popup}>Read More </button>
        </div>
        ))}
        <div id="popup">
           <h1> {popup.description} </h1>
        </div>
        <div className="seperate">

          <aside id="sidebar">
            <div className="dark">
              <h2>HTML Forms</h2>

              <form action="/action_page.php" method="post" onSubmit="this.submit">
                First name:
                <input type="text" id="fname" name="firstname" value="Mickey" />
                Last name:
                <input type="text"  id="lname" name="lastname" value="Mouse" />
                <input type="submit" value="Submit" />
              </form>
            </div>
          </aside>
          

          <aside className="sidebar">
            <div className="dark">
              <h3>Add here</h3>
              <p> contact num</p>
            </div>
            <div className="dark">
              <h3>Add here</h3>
              <p> contact num</p>
            </div>
            <div className="dark">
              <h3>Add here</h3>
              <p> contact num</p>
            </div>
          </aside>
          {/* <hr /> */}
         </div>
      </React.Fragment>
    );
  }
}
export default Sports;
