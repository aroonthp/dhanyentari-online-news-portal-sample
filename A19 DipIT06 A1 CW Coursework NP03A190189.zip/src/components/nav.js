import React, {Component} from'react';
import {Link} from 'react-router-dom'


class Nav extends Component{
	constructor(props){
		super(props);
	}
	render(){

			return(
			<React.Fragment>
				<div className="nav">
				<ul>
					<li>
					{" "}
					<Link to ='/'>
						<button>Home</button>
					</Link>
					</li>
					<li>
					<Link to ='/business'>
						<button>Business</button>
					</Link>
					</li>
					<li>
					<Link to ='/international'>
						<button>International</button>
					</Link>
					</li>
					<li>
					<Link to ='/sports'>
						<button>Sports</button>
					</Link>
					</li>
					<li>
					<Link to ='/entertainment'>
						<button>Entertainment</button>
					</Link>
					</li>
					<Link to ='/About'>
						<button>About</button>
					</Link>
				</ul>
					<div className="searchbar">
						<form action="/action_page.php">
						<input type="text" placeholder="Search.." name="search" />
						<button type="click">search </button>
						</form>
					</div>
					</div>
			</React.Fragment>
	);
	
};
}

export default Nav;
    
