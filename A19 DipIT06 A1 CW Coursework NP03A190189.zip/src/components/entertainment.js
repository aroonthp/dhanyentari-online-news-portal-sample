

import React, { Component } from "react";

class Entertainment extends Component {
  constructor(props) {
    super(props);
    this.state={
        data: [],
        popup: []
    };
  }

              componentDidMount(){
              fetch('http://localhost:5005/Entertaintment')
			.then(response => response.json())
			.then(data => {
                    this.setState({data: data})
				})
		
            .catch(e => console.log(e))
        }
		
			popup = (e) => {
            	if(e.target.classList.contains('btn')){
				let id = e.target.dataset.id
				fetch('http://localhost:5005/Entertainment/'+id)
				.then(response=>response.json())
				.then(data => {
					this.setState({popup: data})			
				})
			}
            }
            
                  
   


  render() {
    const head = {
      display: "inline-block",
      width: "40%"
    };

    const { data } = this.state
    const { popup } = this.state
    console.log(data);
    return (
      <React.Fragment>
          <style>
              @import url('/css/international.css')
          </style>
         
        {data.map(Entertainment=>(
		<div id="container">
		<img src={Entertainment.url} alt="" height="250" width="250"/> 
		<p style={head}>{Entertainment.title}</p>
		<button class="btn" data-id={Entertainment.id} onClick={this.popup}>Read More </button>
        </div>
        ))}
        <div id="popup">
           <h1> {popup.description} </h1>
        </div>
      </React.Fragment>
    );
  }
}
export default Entertainment;
